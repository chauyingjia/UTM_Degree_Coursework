# Implementation Plan: AI-Assisted Data Quality Pipeline

## Tutorial Selected

We selected Tutorial 3:

**The End of Rule-Based Data Quality? How to Use AI Agents Instead**

YouTube link:
https://www.youtube.com/watch?v=Pl3aaM2XHpo

## Project Objective

The objective of this tutorial implementation is to demonstrate how an AI agent can be used inside a data engineering pipeline to perform data quality checking.

Instead of only using hardcoded rule-based checks, the pipeline sends CSV data to an AI agent. The AI agent analyzes the dataset, identifies data quality issues, classifies the issues, and returns a report. The pipeline then continues to a transformation step where pandas applies simple cleaning rules.

## Main Idea

The project demonstrates this concept:

```text
Raw CSV data -> Airflow pipeline -> Airia AI Agent -> Data quality report -> Python cleaning -> Clean CSV output
```

This shows how AI agents can act as a **data quality gate** in a modern data engineering workflow.

## Tools Used

- Apache Airflow: Orchestrates and runs the pipeline tasks.
- Airia AI Agent API: Provides the AI-assisted data quality checking.
- Claude Haiku 4.5: AI model used inside the Airia agent.
- Python: Used to create the Airflow DAG.
- pandas: Used for simple transformation if data passes the quality check.
- requests: Used to call the Airia API.
- WSL Ubuntu: Used to run Airflow because Airflow has compatibility issues on native Windows.

## Files Created

- `customer_data.csv`
  - Dummy customer dataset with intentional data quality issues.

- `airia_dq_pipeline.py`
  - Airflow DAG file containing the full pipeline.

- `requirements.txt`
  - Python dependencies needed for the demo.

- `README.md`
  - Setup and running guide.

- `IMPLEMENTATION_PLAN.md`
  - Explanation and implementation plan for teammates.

## Dataset Used

The file `customer_data.csv` contains sample customer records.

The dataset intentionally includes data quality issues:

- Invalid email format
- Missing age
- Negative age
- Invalid signup date
- Missing country
- Duplicate customer record
- Unrealistic age
- Negative spending amount

These problems were added on purpose so the AI agent can detect them during the pipeline run.

## Airia Agent Design

The Airia agent was updated to follow the tutorial video style more closely.

Instead of using only one AI model block, the Airia workflow now uses multiple AI model blocks connected in sequence:

```text
Input -> AI Model -> AI Model 1 -> AI Model 2 -> Output
```

### AI Model

Purpose:

- Analyze the dataset.
- For each column, report the data type.
- Count null or missing values.
- Detect any visible patterns in the dataset.

Instruction example:

```text
Analyze this dataset. For each column, report: data type, null count, detect any patterns you observe.
```

### AI Model 1

Purpose:

- Use the dataset profile from the previous model.
- Identify data quality issues.
- Detect null fields, duplicate records, format inconsistencies, outliers, and semantic value problems.
- Classify each issue by severity.

Severity categories:

```text
Critical
Warning
Info
```

Instruction example:

```text
Based on the profile above, identify data quality issues including: null fields, duplicate records, format inconsistencies, outliers, and any semantic value. Classify each issue as Critical, Warning, or Info.
```

### AI Model 2

Purpose:

- Generate the final data quality report.
- Summarize total records.
- Summarize issue breakdown by severity.
- List the top issues with examples.
- Recommend possible solutions.

Instruction example:

```text
Generate a concise data quality report summarizing: total records, record issues breakdown by severity, top 5 issues with examples, and a recommended solution.
```

## Airia API Endpoint

The Airflow DAG calls the published Airia agent through this endpoint:

```text
https://api.airia.ai/v2/PipelineExecution/a5323a4c-f6cd-4082-ac07-b52c1f7bc4c5
```

The Airflow code sends the CSV content directly to Airia using `userInput`.

This is important because Airia cannot access a local file path from our computer.

## Airflow DAG Flow

The DAG flow is:

```text
extract_data >> load_data >> airia_data_quality_check >> transform_data
```

## Task Explanation

### 1. extract_data

This task creates or reads the `customer_data.csv` file.

Purpose:

- Simulates extracting data from a source system.
- Provides raw customer data for the pipeline.

### 2. load_data

This task copies the CSV file into a local `staging` folder.

Purpose:

- Simulates loading raw data into a staging area.
- In real data engineering, this could be a database, data warehouse, or cloud storage.

### 3. airia_data_quality_check

This is the main AI-assisted task.

Purpose:

- Reads the staged CSV content.
- Sends the CSV content to the Airia AI Agent API.
- Receives the AI-generated data quality report.
- Checks whether the report contains critical issues.
- Prints the AI-generated data quality report.
- Continues to the transformation task so the demo can clean the dataset.

In this version of the demo, this task does not stop the pipeline when critical issues are found. It acts as an AI-assisted reporting step before cleaning.

### 4. transform_data

This task only runs if the Airia data quality check passes.

Purpose:

- Performs simple cleaning using pandas.
- Writes the cleaned output to `output/customer_data_clean.csv`.

In our demo, this task runs after the AI report and produces a cleaned CSV output.

Example cleaning rules:

- Trim customer names
- Lowercase email addresses
- Fill missing country values with `Unknown`
- Remove duplicate records
- Remove invalid email rows
- Remove invalid age rows
- Remove invalid signup date rows
- Remove negative spending rows

## API Key Handling

The Airia API key is not hardcoded in the code.

It is stored in an environment variable:

```bash
export AIRIA_API_KEY="your_real_airia_api_key_here"
```

The DAG reads it using:

```python
api_key = os.getenv("AIRIA_API_KEY")
```

This is safer because the key is not exposed in the source code.

## Running Steps

### 1. Open Ubuntu WSL

Airflow is run in Ubuntu WSL because Apache Airflow does not run well directly in Windows PowerShell.

### 2. Go to the project folder

```bash
cd ~/st_tutorial
```

### 3. Activate the virtual environment

```bash
source .venv/bin/activate
```

### 4. Install dependencies

```bash
python -m pip install -r requirements.txt
```

### 5. Set the Airia API key

```bash
export AIRIA_API_KEY="your_real_airia_api_key_here"
```

### 6. Copy updated DAG files to the Airflow DAG folder

```bash
mkdir -p ~/airflow/dags
cp airia_dq_pipeline.py ~/airflow/dags/
cp customer_data.csv ~/airflow/dags/
```

### 7. Start Airflow

```bash
![alt text](image.png)
```

If needed:

```bash
python -m airflow standalone
```

### 8. Open Airflow UI

Open the browser:

```text
http://localhost:8080
```

If localhost does not work, use the WSL IP address with port `8080`.

### 9. Trigger the DAG

In the Airflow UI:

1. Search for `airia_dq_pipeline`.
2. Turn on the DAG.
3. Click `Trigger`.
4. Open the DAG run.
5. Check task status and logs.

## Actual Demo Result

The DAG run result was:

```text
extract_data = success
load_data = success
airia_data_quality_check = success with AI issue report
transform_data = success with cleaned CSV output
```

The AI report is expected to show issues because the dataset contains intentional data quality problems.

The Airia agent detected issues such as:

- Invalid email format
- Missing age
- Negative age
- Invalid date format
- Missing country
- Negative spending
- Duplicate records
- Unrealistic age

Because this is the cleaning-version demo, Airflow continues to the transformation step after printing the Airia report.

## Why This Result Is Correct

The `airia_data_quality_check` task shows that the AI agent successfully detected data quality issues.

The `transform_data` task then shows how the pipeline can clean the data after receiving the AI report.

This demonstrates AI-assisted data quality analysis followed by code-based data cleaning.

## How To Explain To Teammates

Use this explanation:

> We implemented an AI-assisted data quality pipeline using Apache Airflow and Airia AI Agent API. Airflow controls the pipeline tasks, while Airia performs the AI data quality check. The Airia agent follows the tutorial video structure by using multiple AI model steps: one step profiles the dataset, one step identifies and classifies quality issues, and one step generates the final report. After the AI report is generated, the pipeline continues to the transformation step, where pandas applies simple cleaning rules and produces a cleaned CSV.

## How To Explain During Presentation

Use this shorter version:

> This demo shows how AI agents can support traditional rule-based data quality checks. The CSV data is passed from Airflow to an Airia AI Agent. The agent profiles the dataset, detects issues, classifies severity, and returns a report. Then the Airflow transformation task uses pandas to clean the data and produce a cleaned CSV output.

## Screenshots To Include In Report

Recommended screenshots:

1. Airia workflow showing `Input -> AI Model -> AI Model 1 -> AI Model 2 -> Output`.
2. Airia instructions for each AI model block.
3. Airflow DAG page showing the task flow.
4. Airflow DAG run showing:
   - `extract_data` success
   - `load_data` success
   - `airia_data_quality_check` success
   - `transform_data` success
5. Airflow logs showing the AI-generated data quality report.
6. The sample `customer_data.csv` dataset.
7. The cleaned output file `output/customer_data_clean.csv`.

## Reflection Points

- AI agents can support data engineers by automating data profiling and data quality analysis.
- This approach is more flexible than writing many manual rules for every possible issue.
- The same pipeline idea can be reused for other datasets by changing the dataset and AI instructions.
- However, AI output can vary, so production systems should combine AI checks with rule-based validation.
- Sensitive data should be handled carefully before sending it to external AI APIs.

## Current Status

The implementation is complete.

The Airia agent now follows the tutorial-style multi-step AI workflow:

```text
Profile dataset -> Identify issues -> Generate report
```

The Airflow DAG successfully calls the Airia agent, prints the AI-generated data quality report, and then runs the transformation step to create a cleaned CSV output.
