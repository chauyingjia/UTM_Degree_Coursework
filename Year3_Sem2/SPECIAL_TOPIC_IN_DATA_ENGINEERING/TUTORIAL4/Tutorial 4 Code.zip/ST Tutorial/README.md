# Airia Data Quality Pipeline Demo

This is a simple Apache Airflow demo project for a university tutorial. The DAG shows an AI-assisted data quality pipeline using the Airia AI Agent API.

The project is for demo purposes only and is not production-level code.

## Files

- `customer_data.csv` - dummy customer dataset with data quality issues
- `airia_dq_pipeline.py` - Airflow DAG file
- `requirements.txt` - Python packages needed for the demo
- `IMPLEMENTATION_PLAN.md` - implementation explanation for teammates
- `README.md` - setup and usage guide

## DAG Flow

```text
extract_data >> load_data >> airia_data_quality_check >> transform_data
```

## Why WSL Ubuntu Is Used

Apache Airflow does not run well directly on native Windows because Airflow depends on Linux/POSIX features. For this demo, Airflow is run inside **WSL Ubuntu**.

The browser still opens from Windows, but the Airflow server runs in Ubuntu.

## Setup Steps In WSL Ubuntu

1. Open Ubuntu WSL.

2. Go to the project folder.

   ```bash
   cd ~/st_tutorial
   ```

3. Create a Python virtual environment if it does not already exist.

   ```bash
   python3 -m venv .venv
   ```

4. Activate the virtual environment.

   ```bash
   source .venv/bin/activate
   ```

5. Install the required packages.

   ```bash
   python -m pip install -r requirements.txt
   ```

6. Set the Airia API key.

   ```bash
   export AIRIA_API_KEY="your_real_airia_api_key_here"
   ```

   The API key is not hardcoded in the Python file.

## How To Run The DAG

1. Copy the DAG file and CSV file into the Airflow DAG folder.

   ```bash
   mkdir -p ~/airflow/dags
   cp airia_dq_pipeline.py ~/airflow/dags/
   cp customer_data.csv ~/airflow/dags/
   ```

2. Start Airflow.

   ```bash
   airflow standalone
   ```

   If needed, use:

   ```bash
   python -m airflow standalone
   ```

3. Keep the terminal running. Airflow only works in the browser while the terminal server is running.

4. Open the Airflow web UI in a browser.

   ```text
   http://localhost:8080
   ```

   If `localhost` does not work, find the WSL IP:

   ```bash
   hostname -I
   ```

   Then open:

   ```text
   http://YOUR_WSL_IP:8080
   ```

5. Find the DAG named `airia_dq_pipeline`.

6. Turn on the DAG and trigger it manually.

## Task Explanation

### 1. extract_data

This task creates or reads the dummy `customer_data.csv` file. The dataset includes common data quality issues such as invalid email format, missing age, negative age, invalid date, missing country, duplicate row, unrealistic age, and negative spending.

### 2. load_data

This task simulates loading data into a staging area. For this demo, it copies `customer_data.csv` into a local `staging` folder.

### 3. airia_data_quality_check

This task reads the staged CSV content and sends the actual CSV text to the Airia API using `requests.post()`. The demo uses the `X-API-KEY` header and sets `asyncOutput` to `False`.

The API key is read from the `AIRIA_API_KEY` environment variable.

If the Airia response reports critical issues, the task prints the report and continues to the transformation task. This lets the demo show AI-assisted issue detection followed by Python-based cleaning.

### 4. transform_data

This task runs after the Airia data quality report. It applies simple pandas cleaning rules, such as trimming text, lowercasing emails, removing duplicate records, removing invalid emails, removing invalid ages, removing invalid dates, removing negative spending rows, and filling missing country values.

It writes the cleaned result to:

```text
output/customer_data_clean.csv
```

## Expected Demo Result

Because the demo dataset intentionally contains bad data, the expected Airflow result is:

```text
extract_data = success
load_data = success
airia_data_quality_check = success with AI issue report
transform_data = success with cleaned CSV output
```

This is correct because the AI data quality check identifies the problems, then the transform task applies cleaning rules and produces a cleaned CSV.

## Important Notes

- The Airia payload sends CSV content directly in `userInput`.
- Airia cannot access a local file path, so the DAG does not send the file path.
- The AI data quality task is expected to report issues for this demo dataset.
- If the Airia agent or endpoint changes, update the `AIRIA_ENDPOINT` value in `airia_dq_pipeline.py`.
